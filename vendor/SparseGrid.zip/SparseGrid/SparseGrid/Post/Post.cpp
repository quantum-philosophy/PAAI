#include "Post.h"

Post::Post()
{	
	 
}


void Post::LoadData(char* filename)
{
	int i,j, rank;
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	ifstream infile(filename);

	if (infile.is_open())
	{
		infile >> dim; 
		infile >> nno; 
		infile >> TotalDof;
		infile >> Level;

		int nsd = 2*dim;
		index.redim(nno,nsd);index.fill(0);
		surplus.redim(nno,TotalDof); surplus.fill(0.0);
		i =1;
		while(infile){
			if(i==nno+1)break;
			for ( j = 1; j<= nsd;j++)
			{    infile >> index(i,j); }
			for ( j = 1; j<=TotalDof; j++)
			{    infile>>surplus(i,j); }

			i++;
		}
		infile.close();
	}
	else
	{
		if(rank == 0)
			printf("Error opening file: %s\n", filename);
		exit(1);
	}  

}

double Post::IndextoCoordinate(int i, int j )
{
	double m = pow(2.0, (i-1)) + 1;
	
	if ( i == 1)
		return 0.5;

    return (j-1.0) / (m-1);

}

double Post::LinearBasis(double x, int i, int j)
{  
	
	//First Level
	if (  i == 1 )
	{return 1.0; }
	else {
		double m = pow(2.0, (i - 1));
		double xp = IndextoCoordinate(i, j );
			if ( fabs( x- xp ) >= (1.0/m))
			{ return 0.0;}
			else 
			{ 
			  return (1- m*fabs(x - xp));
			}
	}
}

void Post::Interpolate(Array<double>& x,double* value)
{
	double  temp;

	for ( int i=0 ; i < TotalDof; i++)
		value[i] = 0.0;
   
   
    for ( int i=1; i<=nno;i++)  
	  { 
          
		  temp = 1.0;
		  for ( int j = 1; j<=dim;j++){			  
			  temp *= LinearBasis(x(j), index(i,j),index(i,j+dim));
			  if ( temp == 0.0) break;
		  }
		  for ( int j = 1; j <= TotalDof; j++)
			  value[j-1] += temp* surplus(i,j);
	 }
}

void Post::Interpolate(double* x, double* value)
{
	Array<double> px;
	px.redim(dim);
	for( int i=1; i<=dim; i++)
		px(i) = x[i-1];

	Interpolate(px,value);

}

void Post::Integrate(double* value)
{
	double temp;
	
	for ( int i=0 ; i < TotalDof; i++)
		value[i] = 0.0;
	
	for ( int i=1; i<=nno;i++)  
	{ 

		temp = 1.0;
		for ( int j = 1; j<=dim;j++){			  

			temp *= LinearBasisVolumeIntegral(index(i,j));

		}
		for ( int j = 1; j <= TotalDof; j++)
			value[j-1] += temp* surplus(i,j);
	}

}

//! integral of the linear basis function
//! if level = 1,  value is 1.0
//! if level = 2,  value is 0.25
//! if others,   value is 2^(1-level).
double Post::LinearBasisVolumeIntegral(int level)
{
	double mul;
	if (  level == 1)
		mul = 1.0;
	else if ( level == 2)
		mul = 0.25;
	else
		mul = pow(2.0, (1-level)/1.0);

	return mul;

}

//! Plot the sparse grid in Tecplot format. You may overload this function
//! to write the grid in your own format
void Post:: PlotSparseGrid(char *filename)
{
	FILE* fp = fopen(filename, "w");
	if ( dim > 3)
	{
		cout<<"ERROR: Dimension can not exceed 3!"<<endl;
		exit(1);
	}
	else{
		fprintf(fp, "VARIABLES =");
		for ( int i=1;i <= dim;i++)
			fprintf(fp, "\"%d\"",i);
		if( dim == 1)
			fprintf(fp,"\"L\"");
		fprintf(fp, "\n");
		fprintf(fp, "ZONE I=%d, F=POINT\n", nno);

	}

	for ( int i = 1 ; i<=nno; i++){
			double x;
			for ( int j = 1; j<= dim ; j++){
				x = IndextoCoordinate(index(i,j),index(i,j+dim) );
				fprintf(fp, "%e\t ", x );
			}
			if ( dim == 1)
				fprintf(fp, "%d\t ", index(i,1) );
			fprintf(fp,"\n");
		}

	fclose(fp);

}