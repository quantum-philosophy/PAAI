

# include "Post.h"



int main(int argc,char **args) {

   Post problem;
   problem.LoadData("suplus.txt");
      
  return 0;
}
