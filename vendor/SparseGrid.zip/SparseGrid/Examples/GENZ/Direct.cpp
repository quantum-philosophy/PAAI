#include "Direct.h"
#include <time.h>
#include <iostream>
using std::cout;

void Direct::Init(int fnum, int d)
{
    problem = new GENZ();
	problem->init(fnum, d);
}

//! Returns the number of output dof's. This is one, a scalar
int Direct::getNumber()
{
	return 1;
}


void Direct::Solve(double* x, double* surplus)
{
	 surplus[0] = problem-> EvaluateFunctionAtThisPoint(x);
}