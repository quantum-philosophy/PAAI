#include "SP4GENZ.h"
#include <time.h>
#include <mpi.h>

//-------------------------------------------------------------
// FORWARD DECLARATIONS
//-------------------------------------------------------------

int simulate();


int main(int argc,char **args)
{
	//Initialize MPI
	MPI_Init (&argc, &args);
	{
	// Simulator class
	 simulate();
	}

	MPI_Finalize (); //Finalize MPI environment.

	return 0;
}

//-------------------------------------------------------------
// MAIN SIMULATOR FUNCTION
//-------------------------------------------------------------
/****************************************************************************/
/* GENZ test functions
/* See Novak and Ritter,  Numerische Mathematik 75 (1996), pp. 79-97) \n");
/* 0: OSCILLATORY
/* 1: PRODCUCT PEAK
/* 2: CORNER PEAK 
/* 3: GAUSSIAN     
/* 4: CONTINUOUS
/* 5: DISCONTINUOUS
/* 6: exp(sum(x[i]))
/* 7: Line Singularity  1.0/(fabs(0.3-x^2-y^2) + 0.1);
/* 8: Point Singlularity 1.0/(fabs(1e-3-x^2-y^2) + 1e-3);
/****************************************************************************/

int simulate()
{

	int fnum = 3;
	int dim = 2;
	int Lmax = 15;
	double epsilon =1e-3;
	int type = 0;

	SP4GENZ sp(dim, Lmax, epsilon, type, fnum);

	int print = 1;
	int restart = 0;
	sp.Solve(print, restart);
	//sp.SaveSurplus();
	//sp.PlotSparseGrid();
	sp.convergence();
	sp.integrate();
	
	return 1;
}