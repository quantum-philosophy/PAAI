#include "GENZ.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>

GENZ::GENZ(){
	
}

GENZ::~GENZ()
{
	delete w,c,cq,cqi;
}


void GENZ::init(int f, int d)
{
	fnum = f;
	dim = d;
	w = new double[dim];
	c = new double[dim];
	cq = new double[dim];
	cqi = new double[dim];

	/************ Generation of a sequence of random numbers **********/
	RandomInitialise(1802,9373);

	double summe=0;
	int i;
	for (i=0; i<dim; i++) {
		c[i] = RandomUniform() ;
		summe += c[i];
	};

	/************Normarlize according to the following***************/
	//  f0     f1      f2      f3     f4     f5   
	//  1.5    d      1.85    7.03   20.4   4.3
	/****************************************************************/

	double normalize;
	switch (fnum) {
	   case 0: normalize = 1.5; break;
	   case 1: normalize = dim; break;
	   case 2: normalize = 1.85; break;
	   case 3: normalize = 7.03; break;
	   case 4: normalize = 20.4; break;
	   case 5: normalize = 4.3; break;
	}

	for (i=0; i<dim; i++){
		c[i]= c[i]/summe * normalize;
		cq[i]=c[i]*c[i];
		cqi[i]=1/cq[i];
	};
  
	/************ Generation of another sequence of random numbers **********/
	summe =0;
	for (i=0; i<dim; i++){
		w[i] = RandomUniform();
		summe += w[i];
	}
	// Normarlize to 1
	for (i=0; i<dim; i++)
		w[i] = w[i] / summe;
    
}

double GENZ::EvaluateFunctionAtThisPoint( double *x)
{
	double value;
	switch (fnum) {
	   case 0: value = f0(x); break;
	   case 1: value = f1(x); break;
	   case 2: value = f2(x); break;
	   case 3: value = f3(x); break;
	   case 4: value = f4(x); break;
	   case 5: value = f5(x); break;
	   case 6: value = f6(x); break;
	   case 7: value = f7(x); break;
	   case 8: value = f8(x); break;
	   default: printf (" no function given, I choose f0 \n");
		   value = f0(x);
		   fnum = 0;
		   break; };

    return value;
}

double GENZ::f0(double *x)
{
	double summe;
	int i;
	double pi = acos(-1.0L);
	summe = 2*pi*w[0];
	for (i=0; i<dim; i++)    summe += c[i]*x[i];
	return cos(summe);
}

double GENZ::f1(double *x)
{
	double summe, hilf;
	int i;
	summe = 1;

	for (i=0; i<dim; i++)
	{
		hilf =x[i]-w[i];
		summe = summe*(cqi[i] + hilf*hilf);
	};
	return 1/summe;
}

double GENZ::f2(double *x)
{
	double summe;
	int i;
	summe = 1;
	for (i=0; i<dim; i++)  summe += c[i]*x[i];
	return pow(summe, -dim-1);
}


double GENZ::f3(double *x)
{
	double summe, hilf;
	int i;
	summe = 0;
	for (i=0; i<dim; i++)
	{
		hilf =x[i]-w[i];
		summe = summe - cq[i]*hilf*hilf;
	};
	return exp(summe);
}

double GENZ::f4(double *x)
{
	double summe;
	int i;
	summe = 0;
	for (i=0; i<dim; i++)  summe = summe - c[i]*fabs(x[i]-w[i]);
	return exp(summe);
}

double GENZ::f5(double *x)
{
	double summe;
	int i;
	if (x[0]>w[0] || x[1]>w[1])
		return 0;
	else
	{
		summe = 0;
		for (i=0; i<dim; i++)  summe += c[i]*x[i];
		return exp(summe);

	};
}


double GENZ::f6(double *x)
{
	double summe;
	int i;
	summe = 0;
	for (i=0; i<dim; i++)    summe += x[i];
	return exp(summe);
}

double GENZ::f7(double *x)
{
	double sum = 0.0;
	for ( int i=0; i<dim;i++)
		sum += pow(x[i],2);

	return 1.0/(fabs(0.3-sum) + 0.1);

}

double GENZ::f8(double *x)
{
	double sum = 0.0;
	for ( int i=0; i< dim;i++)
		sum += pow(-1+2*x[i],2);

	return 1.0/(fabs(1e-3-sum) + 1e-3);

}


/************ Calculate and print the exact integral ********************/
double GENZ::ExactIntegral()
{
	if ( fnum > 6 )
	{
		printf("ERROR: Function is not implemented!\n");
		exit(1);
	}

	Integral Exact;

	return Exact.integral(fnum, dim, w, c);

}

void GENZ::RandomInitialise(int ij,int kl)
{
   double s,t;
   int ii,i,j,k,l,jj,m;

   /*
      Handle the seed range errors
         First random number seed must be between 0 and 31328
         Second seed must have a value between 0 and 30081
   */
   if (ij < 0 || ij > 31328 || kl < 0 || kl > 30081) {
		ij = 1802;
		kl = 9373;
   }

   i = (ij / 177) % 177 + 2;
   j = (ij % 177)       + 2;
   k = (kl / 169) % 178 + 1;
   l = (kl % 169);

   for (ii=0; ii<97; ii++) {
      s = 0.0;
      t = 0.5;
      for (jj=0; jj<24; jj++) {
         m = (((i * j) % 179) * k) % 179;
         i = j;
         j = k;
         k = m;
         l = (53 * l + 1) % 169;
         if (((l * m % 64)) >= 32)
            s += t;
         t *= 0.5;
      }
      u[ii] = s;
   }

   d    = 362436.0 / 16777216.0;
   cd   = 7654321.0 / 16777216.0;
   cm   = 16777213.0 / 16777216.0;
   i97  = 97;
   j97  = 33;
  
}

/*
   This is the random number generator proposed by George Marsaglia in
   Florida State University Report: FSU-SCRI-87-50
*/
double GENZ::RandomUniform(void)
{
   double uni;

   uni = u[i97-1] - u[j97-1];
   if (uni <= 0.0)
      uni++;
   u[i97-1] = uni;
   i97--;
   if (i97 == 0)
      i97 = 97;
   j97--;
   if (j97 == 0)
      j97 = 97;
   d -= cd;
   if (d < 0.0)
      d += cm;
   uni -= d;
   if (uni < 0.0)
      uni++;

   return(uni);
}