/*
  Filename : GENZ.h
  Prepared by : Xiang Ma and Nicholas Zabaras
  Version : March 14, 2008
*/

#ifndef GENZ_h_is_included
#define GENZ_h_is_included


#include "Integral.h"

//-------------------------------------------------------------
// MAIN SIMULATOR FUNCTION
//-------------------------------------------------------------
/****************************************************************************/
/* GENZ test functions
/* See Novak and Ritter,  Numerische Mathematik 75 (1996), pp. 79-97) \n");
/* 0: OSCILLATORY
/* 1: PRODCUCT PEAK
/* 2: CORNER PEAK 
/* 3: GAUSSIAN     
/* 4: CONTINUOUS
/* 5: DISCONTINUOUS
/* 6: exp(sum(x[i]))
/****************************************************************************/

class GENZ
{

public:

	GENZ();
	~GENZ();

   int fnum;                   // Function number
   int dim;                    // Dimension

   double *w, *c, *cq, *cqi;

   double u[97],d,cd,cm;

   int i97,j97;

   void init(int fnum, int dim);

   virtual void   RandomInitialise(int,int);

   virtual double RandomUniform(void);


   virtual double EvaluateFunctionAtThisPoint(double *x);
  

   double f0(double *x);
   double f1(double *x);
   double f2(double *x);
   double f3(double *x);
   double f4(double *x);
   double f5(double *x);
   double f6(double *x);
   double f7(double *x);
   double f8(double *x);


   //Exact integral for function from 0--6
   double ExactIntegral();


};
#endif
/*Class:GENZ

NAME:  GENZ - Implimentation of GENZ test package

DESCRIPTION:

  The function 0-6 are from the GENZ test package. Both interpolation and integration are
  compared.

  7 and 8 are two particular two-dimensional singularity functions to test the adaptivity.

   /* GENZ test functions
   /* See Novak and Ritter,  Numerische Mathematik 75 (1996), pp. 79-97) \n");
   /* 0: OSCILLATORY
   /* 1: PRODCUCT PEAK
   /* 2: CORNER PEAK
   /* 3: GAUSSIAN
   /* 4: CONTINUOUS
   /* 5: DISCONTINUOUS
   /* 6: exp(sum(x[i]))
   /* 7: Line Singularity  1.0/(fabs(0.3-x^2-y^2) + 0.1);
   /* 8: Point Singlularity 1.0/(fabs(1e-3-x^2-y^2) + 1e-3);


CONSTRUCTORS AND INITIALIZATION:

	\param fnum    The number of the function
    \param dim     The dimension of the function
	\param Lmax    The allowed maximum interpolation level
	\param epsilon The error criteria to control the adaptivity. By using
	               epsilon == 0, it goes back to the conventional sparse grid


MEMBER FUNCTIONS:

  Most member functions are self-explanatory.

  "ExactIntegral"   -  Give the exact value of the integration of the GENZ test function in the unit hypercube.



COPYRIGHT:

        Professor Nicholas Zabaras
        Materials Process Design & Control Laboratory
        Sibley School of Mechanical and Aerospace Engineering
        101 Frank H. T. Rhodes Hall
        Cornell University
        Ithaca, NY 14853-3801

        Email: zabaras@cornell.edu
        Phone: 607 255 9104
        Fax:   607 255 1222


AUTHOR:

  Xiang Ma, xm25@cornell.edu

End:
*/