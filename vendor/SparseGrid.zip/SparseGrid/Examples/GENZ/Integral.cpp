# include <math.h>
# include <stdio.h>
# include <stdlib.h>
# include "Integral.h"

Integral::Integral()
{

}

long double Integral::integrate(int fnum, int dim, int d,long double sum, double w[], double c[])
{
  double prod, pi,arg;
  int i;
  pi=4*atan(1.0);
  switch (fnum) {
  case 0:
    /*if (d>0)
      return (integrate(fnum,dim, d-1, sum+c[d-1], w, c)
	       - integrate(fnum,dim,d-1, sum, w , c))/c[d-1];
    else
      switch (dim%4) {
      case 0: return cos(2*pi*w[0] + sum);
      case 1: return sin(2.0*pi*w[0] + sum);
      case 2: return -cos(2*pi*w[0] + sum);
      case 3: return -sin(2*pi*w[0] + sum);
      };*/
	  arg = 0.0;
	  for ( i = 0; i < dim; i++ )
	  {
		  arg = arg + c[i];
	  }

	  prod = 1.0;
	  for ( i = 0; i < dim; i++ )
	  {
		  prod = prod * sin ( 0.5 * c[i] ) / c[i];
	  }

	  return  pow ( 2.0, dim ) * cos ( 2.0 * pi * w[0] + 0.5 * arg ) * prod;

  case 1:
    prod=1;
    for (i=0; i<dim; i++)
      prod=prod*c[i]*(atan(c[i]*(1-w[i]))+atan(c[i]*w[i]));
    return prod;
  case 2:
    if (d>0)
      return ( integrate(fnum,dim,d-1, sum, w,c) - integrate(fnum,dim,d-1, sum+c[d-1], w,c)) /(d*c[d-1]);
    else
      return 1/(1+sum);
  case 3:
	init_erf();
    prod=1;
    for (i=0; i<dim; i++){
      prod=prod*sqrt(pi)/(2*c[i])*( my_erfc(-c[i]*w[i])
				   -my_erfc(c[i]*(1-w[i])));
   };
    return prod;
  case 4:
    prod=1;
    for (i=0; i<dim; i++)
      prod=prod/c[i]*(2-exp(-c[i]*w[i])-exp(c[i]*(w[i]-1)));
    return prod;
  case 5:
    /*if (d>2)
      return ( integrate(fnum,dim,d-1, sum+c[d-1], w,c)
	       - integrate(fnum,dim,d-1, sum,w,c)) /c[d-1];
    else
      if (d>0)
	return ( integrate(fnum,dim,d-1, sum+w[d-1]*c[d-1],w,c)
		 - integrate(fnum,dim,d-1, sum,w,c)) /c[d-1];
      else
	return exp(sum);*/
	 prod = 1.0;
 
    if ( dim < 2 )
    {
      for ( i = 0; i < dim; i++ )
      {
        prod = prod * ( exp ( c[i] * w[i] ) - 1.0 ) / c[i];
      }
    }
    else
    {
      for ( i = 0; i <= 1; i++ )
      {
        prod = prod * ( exp ( c[i] * w[i] ) - 1.0 ) / c[i];
      }
      for ( i = 2; i < dim; i++ )
      {
        prod = prod * ( exp ( c[i] ) - 1.0 ) / c[i];
      }
    }
     return prod;
  case 6:
    prod=pow(exp(1.0)-1, d);
    return prod;
  
  default: return 0;
  };
}


double Integral::integral(int fnum, int dim, double w[], double c[])
{
  double wert;
  wert=integrate(fnum, dim, dim, 0.0, w, c);
 return wert;
}



double Integral::my_erfc( double x)
{
  double sm, prod[60], h, hilf, smme;
  int i, j;
  if (x<0)
    return 2.0-my_erfc(-x); 
  else
    {
      if (x<7.5)
	{
	  i = x+0.499999; 
	  h = x-i;
	  sm = h*derf[i][19]+derf[i][18]; 
	  for (j=17; j>=0; j--)
	    sm = h*sm +derf[i][j];	  
	  return sm; 
	}
      else
	{
	  hilf=0.5/pow(x,2);
	  prod[0]=1;
	  i = 2+190/x;
	  for (j=1; j<=i; j++)
	    { prod[j] = -prod[j-1]*(2*j-1)*hilf; 
	    };
	  smme = 0;
	  for (j=i; j>=0; j--)
	  smme  +=prod[j]; 
	  return smme *exp(-pow(x,2))/(wp*x);
	};
    };
};

void Integral::init_erf()
{
  double ii, h, hilf, one, pi;
  int i,j;
  one=1;
  pi=4*atan(1.0);
  wp = sqrt(pi);
  hilf = 2/wp;
  derf[0][0] = 1.0;
  derf[1][0] = 1.5729920705028513065877936491E-1;
  derf[2][0] = 4.6777349810472658379307436327E-3;
  derf[3][0] = 2.2090496998585441372776129582E-5;
  derf[4][0] = 1.5417257900280018852159673486E-8;
  derf[5][0] = 1.5374597944280348501883434853E-12;
  derf[6][0] = 2.1519736712498913116593350399E-17;
  derf[7][0] = 4.1838256077794143986140102238E-23;
  for (i=0; i<=7; i++)
    {
      ii = i;
      derf[i][1] = -exp(-pow(ii,2))*hilf;
      derf[i][2] = -ii*derf[i][1]; 
      for (j=3; j<=19; j++)
	derf[i][j] = -2.0*(ii*derf[i][j-1] + (j-2)*derf[i][j-2]/(j-1))/j; 
    };
};


