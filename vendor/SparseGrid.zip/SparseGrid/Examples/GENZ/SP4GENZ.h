#ifndef SP4GENZ_h_is_included
#define SP4GENZ_h_is_included


#include "SparseGrid.h"
#include "Direct.h"
#include "GENZ.h"

class SP4GENZ: public AdaptiveSparseGrid
{

public:
   
	SP4GENZ(int dim ,int Lmax,double epsilon, int type, int fnum);
	~SP4GENZ(){};

	int fnum;

   virtual void Solve(int print_ = 1, int restart_ = 0, char* filename = "surplus.plt");
   //Overloaded function from AdaptiveSparseGrid
   virtual void   EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x);
   virtual void   SaveSurplus();
   virtual void   AfterStoreSurplus();
   Direct problem;

    //For error check purpose
   void convergence();
   void integrate();
   void interpolate();


};
#endif

  /*"convergence"   -  Caluate and store the maximum and L2 interpolation error over 1000 random points.

  "integrate"       -  Compare the integration value between exact and that through sparse grid.

  "interpolate"     - Only for two dimension case. Plot the exact and interpolated value on a 100X100 uniform mesh.
                      You can use Matlabe to plot the data file. 
  
  */