#ifndef Direct_h_IS_INCLUDED
#define Direct_h_IS_INCLUDED


#include "GENZ.h"


class Direct
{

public:
	Direct(){};
	~Direct(){delete problem;};
	virtual void Init(int fnum,int dim);
	
	virtual void Solve(double* x, double* surplus);

	GENZ* problem;
	//! Returns the number of output dof's. This is one, a scalar
	virtual int 	getNumber();


};

#endif