#include "SP4GENZ.h"

SP4GENZ::SP4GENZ(int dim_, int Lmax_, double epsilon_, int type_,int fnum_):AdaptiveSparseGrid(dim_,Lmax_,epsilon_,type_)
{
	dim = dim_;
	Lmax = Lmax_;
	epsilon = epsilon_;
	fnum = fnum_;
	
}


void SP4GENZ:: Solve(int print, int restart, char* filename)
{
	
	NumberToStore = problem.getNumber();
    DofPerNode = 1;
	TotalDof = NumberToStore*DofPerNode;

	surplus    = new double[TotalDof];

	problem. Init(fnum,dim);  

	double tm1,tm2;
    tm1 = MPI_Wtime();
    BuildAdaptiveSparseGrid(print,restart,filename);
    tm2 = MPI_Wtime();

	int NoPoint = NumberOfPoints();

	if(rank==0){
		printf("Construct the adaptive sparse grid use (%5.2fs)\n",(tm2-tm1));

		cout<<"The number of the grid is :" <<NoPoint<<"\n";
		cout<<"The depth  of the grid is :" <<InterpolationLevel()<<"\n\n";
	}
    

}

void SP4GENZ::EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x)
{
	 	
	problem.Solve(x->pData, surplus);
	
}


void SP4GENZ::SaveSurplus()
{
    AdaptiveARRAY<int> index; index.redim(TotalDof);
   for ( int i=1; i<=TotalDof; i++)
	    index(i) = i-1;

   StoreSurplus(index);  
}

void SP4GENZ::AfterStoreSurplus()
{
	// If you need to plot the evolution of the grid, uncomment it.
	//PlotSparseGrid();
}

void SP4GENZ::convergence()
{
	/////////////////////////////////////
	/*** For high dimensional test******/
	/////////////////////////////////////
	const int M = 100;
	double Maxerr = 0.0, norm = 0.0;
	double L2error = 0.0, error,exact;
	double *fvalue = new double[TotalDof];
	AdaptiveARRAY<double> x; x.redim(dim);


	for (int k = 1; k<= M; k++){
		for ( int j = 1; j<=dim; j++){
			x(j) = problem.problem->RandomUniform();
		}
		EvaluateFunctionAtThisPoint(&x);
		exact = surplus[0];
		SpInterpolate(&x,fvalue);
		error = fvalue[0] - exact;
		if ( fabs(error) >= Maxerr) Maxerr = fabs(error);
		L2error += pow(error,2);
		norm += pow(exact,2.0);
	}
    
	int number = NumberOfPoints();
    
	if ( rank == 0){

		printf("The Maximum   error    is: %e\n", Maxerr);
		printf("The relative  L2 error is: %e\n\n", sqrt(L2error)/sqrt(norm));
	}
	delete[] fvalue;
}

void SP4GENZ::integrate()
{
    if ( fnum == 7 || fnum == 8)
	{   
		cout<<"ERROR: There is no analytic solution for this function!\n";
		return;
	}

	double error;
	double *fvalue = new double[TotalDof];
	double exact;

	exact = problem.problem->ExactIntegral();
	SpIntegrate(fvalue);
	error = fabs(fvalue[0] - exact);
    int number = NumberOfPoints();
	if (rank == 0){
	printf("\nThe        exact         value is: %e\n", exact);
	printf("The        integrate     value is: %e\n", fvalue[0]);
	printf("The relative integration error is: %e\n", error/exact);
	}
	delete[] fvalue;
	
}

void  SP4GENZ::interpolate()
{   
	if ( dim != 2){
		printf("ERROR: The dimension must be 2!\n");
		return;
	}

	double Maxerr = 0.0, norm = 0.0;
	double L2error = 0.0, error,exact;
	double *fvalue = new double[TotalDof];
	AdaptiveARRAY<double> x;x.redim(2);
    FILE *fp1, *fp2;
	if (rank ==0){
	 fp1 = fopen("Interpolate.plt", "w");
	 fp2 = fopen("Original.plt","w");
	}
	for ( x(1)=0.0; x(1)<=1.001; x(1)+=0.01){
		for ( x(2)=0.0; x(2)<=1.001; x(2)+=0.01){
			EvaluateFunctionAtThisPoint(&x);
		    exact = surplus[0];
		    SpInterpolate(&x,fvalue);
			if (rank == 0){
			fprintf(fp1, "%e\t ",fvalue[0] );
			fprintf(fp2, "%e\t ",exact );
			}
			error = fvalue[0] - exact;
			if ( fabs(error) >= Maxerr) Maxerr = fabs(error);
			L2error += pow(error,2);
			norm += pow(exact,2.0);
		}
		if (rank ==0){
		fprintf(fp1, "\n");
		fprintf(fp2, "\n");
		}
	}
	if (rank == 0){
	fclose(fp1);
	fclose(fp2);
	printf("The Maximum   error    is: %e\n", Maxerr);
	printf("The relative  L2 error is: %e\n\n", sqrt(L2error)/sqrt(norm));
	}
	delete[] fvalue;
}