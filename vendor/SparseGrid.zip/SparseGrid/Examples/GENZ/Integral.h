/*
  Filename : Integral.h
  Prepared by : Xiang Ma and Nicholas Zabaras
  Version : March 14, 2008
*/
#ifndef Integral_h_IS_INCLUDED
#define Integral_h_IS_INCLUDED


class Integral
{
public:

  Integral();
  ~Integral(){};


  virtual  double integral(int fnum, int dim, double *w, double *c);

  virtual  long double integrate(int fnum, int dim, int d,long double sum, double *w, double *c);

  void init_erf();

  double my_erfc( double x);

  double  derf[8][20], wp;

};

#endif
/*Class:Integral

NAME:  Integral - This is the class caculating the analyitcal integration of the GENZ function package.

DESCRIPTION:

  This class caculate the analyitcal integration of the GENZ function package for the verification
  of the sparse grid code.


CONSTRUCTORS AND INITIALIZATION:

    fnum - function number

	dim  - dimesnion

	w    - weights in the function

	c    - parameters in the function


MEMBER FUNCTIONS:


  Most member functions are self-explanatory.


COPYRIGHT:

        Professor Nicholas Zabaras
        Materials Process Design & Control Laboratory
        Sibley School of Mechanical and Aerospace Engineering
        101 Frank H. T. Rhodes Hall
        Cornell University
        Ithaca, NY 14853-3801

        Email: zabaras@cornell.edu
        Phone: 607 255 9104
        Fax:   607 255 1222


AUTHOR:

  Xiang Ma, xm25@cornell.edu

End:
*/
