//  MyHeat1_steady.C: implementation of the  MyHeat1_steady class.
//
//////////////////////////////////////////////////////////////////////
#include <time.h>
#include "MyHeat.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

double& Heat2DNodeData::value(int index){
	switch(index){
	case 0:
		return theta;
	default:
		printf("no such data\n");
		exit(0);
	}
	return theta;
}

char* Heat2DNodeData::name(int index){
	static char name[256];
	switch(index){
	case 0: strcpy(name, "theta"); break;
	default:
		printf("no such data\n");
		exit(0);
	}
	return name;
}
int Heat2DNodeData::valueno(){
	return 1;
}
void Heat2DNodeData::UpdateDataStructures()
{	
}




 MyHeat:: MyHeat() :CEquation<Heat2DNodeData, Heat2DGPData, Heat2DSurfaceGPData>()
{
	linear=1;
	this->bSerial = true;
    
	

}

void  MyHeat::init(double L_, int d_)
{
   L_c = L_;
   d = d_;
}



void  MyHeat::fillEssBC ()
{
	initEssBC();

	for(int nodeID=1; nodeID<=pGrid->nodeno; nodeID++){	
		
		if( pGrid->BoNode(nodeID) ){
			specifyValue(nodeID, 1,0.0  );			
		}
	}
}


void  MyHeat::Solve(double* x, double* surplus)
{	
	this->dt = 0;
	this->t= 0;

	Y.redim( d);

	for ( int i=1; i<= Y.n; i++){
		Y(i) = -sqrt(3.0) + 2*sqrt(3.0)*x[i-1];
	}
   
	fillEssBC();
	ApplyEssBCToSolution();
   
	
	Assemble(1);
	ApplyEssBC(linear);
   
	SolveKSP(solution,1,0); 
	

	for(int A=0; A<pGrid->nodeno; A++){		
		//copy solution to node data
		surplus[2*A] = solution( A+1);
		surplus[2*A + 1] = sqr(solution(A+1));
	}
	 
}





void  MyHeat::integrands(FEMElm& fe, Matrix<double>& Ae, ARRAY<double>& be)
{   
	const int elmID=fe.elmID;
	const int gpID =fe.getCurrentItgPt ();
	const double detJxW=fe.detJxW();
	const int nsd=2;
	const int nbf=fe.pElm->nodeno;
	
    
	PTV x(nsd);
	fe.getGlobalEvalPt(x);
	double f_value = cos(x(1))*sin(x(2));
    double k_value = a(x(1));
      
	int a,b;
	double M=0;
	double N=0;

	for(a=1; a<=nbf; a++){
		//////Matrix
		for(b=1; b<=nbf; b++){
			//cal M_ij
			//cal N_ij
			N = 0;
			for(int k=1; k<=nsd; k++){
				N +=  k_value*fe.dN(a,k)*fe.dN(b,k)*detJxW;
			}
			Ae(a,b) += N;
		}
			//vector
			be(a) += fe.N(a)*f_value*detJxW;
		
	}
}



double  MyHeat::a(double x)
{
	double sum = 1.0;
	
	double L_p = max(1.0,2*L_c);

	double L = L_c/L_p;

	sum += Y(1)*sqrt( sqrt(M_PI)*L/2.0);
  
	for ( int i = 2; i<= d; i++){
		double temp;
		temp = sqrt( sqrt(M_PI)*L) * exp(-sqr((i/2))*sqr(M_PI)*sqr(L)/8.0);
		if ( i%2==0)
		    temp *= sin((i/2)*M_PI*x/L_p);
		else
			temp *= cos((i/2)*M_PI*x/L_p);
		temp *= Y(i);
		sum += temp;

	}
	return 0.5+exp(sum);
	
}












