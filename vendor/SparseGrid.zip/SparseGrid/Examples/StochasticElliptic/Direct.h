#ifndef Direct_h_IS_INCLUDED
#define Direct_h_IS_INCLUDED


#include "include.h"
using namespace TALYFEMLIB;
#include "MyHeat.h"

class Direct
{

public:
	Direct(){};
	~Direct(){};
	void Init(double L_c, int dim);
	
	virtual void Solve(double* x, double* surplus);


	MyHeat problem;
	GRIDBox2D grid;
	GridField<Heat2DNodeData,  Heat2DGPData, Heat2DSurfaceGPData> heatData;

	int nno;

	int	getNumber();

	int dim;


};

#endif