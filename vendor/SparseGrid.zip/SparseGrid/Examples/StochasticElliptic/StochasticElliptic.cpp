#include "StochasticElliptic.h"

StochasticElliptic::StochasticElliptic(int dim_, int Lmax_, double epsilon_):AdaptiveSparseGrid(dim_,Lmax_,epsilon_)
{
	dim = dim_;
	Lmax = Lmax_;
	epsilon = epsilon_;
	}

void StochasticElliptic::SetCorrelationLength(double L_c)
{
	this->L_c = L_c;
}

void StochasticElliptic:: Solve(int print, int restart, char* filename)
{
	problem.Init(L_c, dim);

	NumberToStore = problem.getNumber();
	DofPerNode = 2;
	TotalDof = NumberToStore*DofPerNode;

	surplus    = new double[TotalDof];

	mean.redim(NumberToStore) ; var .redim(NumberToStore);

	double tm1,tm2;
    tm1 = MPI_Wtime();
    BuildAdaptiveSparseGrid(print,restart,filename);
    tm2 = MPI_Wtime();

	int NoPoint = NumberOfPoints();

	if(rank==0){
		printf("Construct the adaptive sparse grid use (%5.2fs)\n",(tm2-tm1));

		cout<<"The number of the grid is :" <<NoPoint<<"\n";
		cout<<"The depth  of the grid is :" <<InterpolationLevel()<<"\n\n";
	}
	
    
    postprocess();
	
}



void StochasticElliptic::EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x)
{	
	
	problem.Solve(x->pData,surplus);
	
	
}

void StochasticElliptic::postprocess()
{
    char filename[80];

	double* stat= new double[TotalDof];;
	//! Calculate the variance first. It depends on how you store the hierarchical surplus
	//! Here I store it as mean variance mean variance ......alternativly.
	SpIntegrate(stat);

	for ( int k = 0; k < NumberToStore; k++){
	    mean(k+1) = stat[2*k];
		var(k+1)  = stat[2*k+1] - pow(stat[2*k],2); 
	}

	sprintf(filename,"mean_level_%d.plt",InterpolationLevel());
	PrintFile(filename, mean);
	sprintf(filename,"var_level_%d.plt",InterpolationLevel());
    PrintFile(filename , var);
}

void StochasticElliptic::PrintFile(char *filename,ARRAY<double>& value)
{
	    GRIDBox2D grid;

		double dx = 1.0;
		int nx = 30;

		grid.redimBox(  dx, dx, nx, nx);	

        FILE *fp=fopen(filename, "w");

		const int nel= grid.elmno;
		const int nno = grid.nodeno;


		fprintf(fp, "VARIABLES = \"x\"\"y\" ");

		fprintf(fp, " \"T\" ");

		fprintf(fp,"\n");

		fprintf(fp,"ZONE N=%d, E=%d, F=FEPOINT, ET=QUADRILATERAL\n", nno , nel );

		for(int i=1; i<=nno; i++){
			double xc, yc;
			xc=grid.getCoor(i,1); yc=grid.getCoor(i,2);
			fprintf(fp, "%e\t %e\t ", xc, yc);
			fprintf(fp, "  %1.10e\t" , value(i));
			fprintf(fp, "\n");
		}
		fprintf(fp, "\n\n\n");
		for(int i=1; i <= nel; i++){
			fprintf(fp,"%d %d %d %d\n",grid.loc2glob(i,1),grid.loc2glob(i,2),grid.loc2glob(i,3),grid.loc2glob(i,4));
		}
		fclose(fp);
}
