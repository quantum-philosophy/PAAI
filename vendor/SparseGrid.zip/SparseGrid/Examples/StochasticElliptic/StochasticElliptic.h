/*
  Filename : StochasticElliptic.h
  Prepared by : Xiang Ma and Nicholas Zabaras
  Version : July 22, 2008
*/

#ifndef StochasticElliptic_h_is_included
#define StochasticElliptic_h_is_included

#include "include.h"
using namespace TALYFEMLIB;
#include "Direct.h"
#include "SparseGrid.h"


class StochasticElliptic: public AdaptiveSparseGrid
{

public:

	StochasticElliptic(int dim ,int Lmax,double epsilon);
	~StochasticElliptic(){};

	virtual void SetCorrelationLength(double L_c);
	virtual void Solve(int print_ = 1, int restart_ = 0, char* filename = "surplus.plt");
	//Overloaded function from AdaptiveSparseGrid
	virtual void   EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x);
	virtual void   postprocess();


	Direct problem;
	

	void PrintFile(char *filename,ARRAY<double>& value);
	int number;
	double L_c;

	ARRAY<double> mean,var;

};
#endif

/*Class:StochasticElliptic

NAME:  StochasticElliptic - This is the class to solve a stochastic elliptic problem with random diffusivity.

DESCRIPTION:

  <b>This class solves the stochastic problem.</b>

  For problem definition, please refer to the following paper:

  <b> Xiang Ma and N. Zabaras </b>
  An adaptive hierarchical sparse grid collocation algorithm for the solution
  of the stochastic differential equations, Journal of Computational Physics, Vol. 228, pp. 3084-3113, 2009.

  At each collocation point, you need to solve a elliptic stochastic problem ( here is defined as
  MyHeat) using MPDC finite element library. For detailed description, please consult the documentation.

CONSTRUCTORS AND INITIALIZATION:

   Use the same constructer as base class.

   You need to provide the the correlation length L in the function Solve().


MEMBER FUNCTIONS:


  Most member functions are self-explanatory.


COPYRIGHT:

        Professor Nicholas Zabaras
        Materials Process Design & Control Laboratory
        Sibley School of Mechanical and Aerospace Engineering
        101 Frank H. T. Rhodes Hall
        Cornell University
        Ithaca, NY 14853-3801

        Email: zabaras@cornell.edu
        Phone: 607 255 9104
        Fax:   607 255 1222


AUTHOR:

  Xiang Ma, xm25@cornell.edu

End:
*/