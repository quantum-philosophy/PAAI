#include "Direct.h"
#include <time.h>


void Direct::Init(double L_c, int d)
{
	double dx = 1.0;
	int nx = 30;

	grid.redimBox(  dx, dx, nx, nx);	

	heatData.redimGrid(&grid);
	heatData.redimNodeData();
	heatData.redimElmData();

	nno = heatData.pGrid->nodeno;

	problem.redimSolver ( &grid, 1);
	problem.setData( &heatData );   
	problem.init(L_c, d);
  
	this->dim = d;
}

int Direct::getNumber()
{
	//1. return the saturation data number
	return nno;

}

void Direct::Solve(double* x, double* surplus)
{
	
    problem. Solve(x,surplus);
}

