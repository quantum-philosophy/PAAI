#include "include.h"
using namespace TALYFEMLIB;

#include "StochasticElliptic.h"
#include <time.h>


static char help[] = "Example Use of Sparse Grid Interpolation Tool Box";
static int ierr;


//-------------------------------------------------------------
// FORWARD DECLARATIONS
//-------------------------------------------------------------

int simulate();

int main(int argc,char **args)
{
	//Initialize Petsc
	PetscInitialize(&argc,&args,(char *)0,help);
	{
	// Simulator class
	 simulate();
	}
	// Finalize Petsc
	
	ierr = PetscFinalize();

	CHKERRQ(ierr);

	return 0;
}

//-------------------------------------------------------------
// MAIN SIMULATOR FUNCTION
//-------------------------------------------------------------
int simulate()
{

	int dim = 3;
	int Lmax = 10 ;
	double epsilon = 1e-5;

	StochasticElliptic sp(dim,Lmax,epsilon);

	double L = 0.75;
	sp.SetCorrelationLength(L);
	sp.Solve();


	return 1;
}

