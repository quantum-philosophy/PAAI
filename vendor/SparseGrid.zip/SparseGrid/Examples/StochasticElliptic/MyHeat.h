#ifndef MyHeat_h_IS_INCLUDED
#define MyHeat_h_IS_INCLUDED

#include "include.h"
using namespace TALYFEMLIB;
#include "SparseGrid.h"


class Heat2DNodeData
{
public:
	Heat2DNodeData(){
		theta=0;
	};
	virtual ~Heat2DNodeData(){};

	virtual double& value(int index);
	static char* name(int index);
	static int valueno();
	virtual void UpdateDataStructures();
	double theta;
};



class Heat2DGPData
{
public:
	Heat2DGPData(){
	};
	virtual ~Heat2DGPData(){};
	virtual void UpdateDataStructures()
	{
	}
};

class Heat2DSurfaceGPData
{
public:
	Heat2DSurfaceGPData(){
	};
	~Heat2DSurfaceGPData(){};
	virtual void UpdateDataStructures(){
	}
};


class  MyHeat: public CEquation<Heat2DNodeData, Heat2DGPData, Heat2DSurfaceGPData>
{
public:
	 MyHeat();

	virtual void fillEssBC ();
	virtual void Solve(double* x, double *surplus);

	virtual void integrands(FEMElm& fe, Matrix<double>& Ae, ARRAY<double>& be);

	virtual double a(double x);

	virtual void init(double L_, int d_);

	ARRAY<double> Y;

    double L_c;
	int d;



};

#endif

