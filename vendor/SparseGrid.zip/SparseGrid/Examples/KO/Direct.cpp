#include "Direct.h"
#include <time.h>
#include <iostream>
using std::cout;

void Direct::Init(int step, int dim)
{
    problem = new KO();
	problem->init(step, dim);
}


void Direct::Solve(double* x, double* surplus)
{
	 problem->Solve(x,surplus);
}