#ifndef Direct_h_IS_INCLUDED
#define Direct_h_IS_INCLUDED


#include "KO.h"


class Direct
{

public:
	Direct(){};
	~Direct(){delete problem;};
	
	virtual void Init(int step, int dim);
	
	virtual void Solve(double* x, double* surplus);

	KO* problem;


};

#endif