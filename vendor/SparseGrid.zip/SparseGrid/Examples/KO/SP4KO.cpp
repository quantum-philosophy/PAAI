#include "SP4KO.h"

SP4KO::SP4KO(int dim_, int Lmax_, double epsilon_, int type_):AdaptiveSparseGrid(dim_,Lmax_,epsilon_,type_)
{
	dim = dim_;
	Lmax = Lmax_;
	epsilon = epsilon_;
}

void  SP4KO:: SetTimeStep(int step)
{
	no_time_step = step;
}

void SP4KO:: Solve(int print, int restart, char* filename)
{
	
	NumberToStore = (no_time_step-1)/10 + 1;
    DofPerNode = 6;
	TotalDof = NumberToStore*DofPerNode;

	surplus    = new double[TotalDof];

	problem. Init(no_time_step, dim);  

	double tm1,tm2;
    tm1 = MPI_Wtime();
    BuildAdaptiveSparseGrid(print,restart,filename);
    tm2 = MPI_Wtime();

	int NoPoint = NumberOfPoints();

	if(rank==0){
		printf("Construct the adaptive sparse grid use (%5.2fs)\n",(tm2-tm1));
        cout<<"The time step is          :" <<no_time_step<<"\n";
		cout<<"The number of the grid is :" <<NoPoint<<"\n";
		cout<<"The depth  of the grid is :" <<InterpolationLevel()<<"\n\n";
	}
    
    Postprocess();
}

void SP4KO::EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x)
{
	 	
	problem.Solve(x->pData, surplus);
	
}

int SP4KO::IsRefine(double* value,AdaptiveARRAY<int> *ix,AdaptiveARRAY<int> *iy)
{
   double maximum = max ( fabs(value[TotalDof - 5]), fabs(value[TotalDof - 3])); 
   maximum = max(maximum, fabs(value[TotalDof - 1]));
   
   if ( maximum >= epsilon ) return 1;
   else return 0;
}

void SP4KO::Postprocess()
{
    char filename[80];
	sprintf(filename,"result%1.5f.plt",epsilon);
	
	ComputeMeanAndVar(filename);

	//Plot Sparse Grid
	PlotSparseGrid("grid.plt");

}


void  SP4KO:: StoreMeanAndVar(double* stat,char *filename)
{
 
  FILE* fp = fopen(filename, "w");
  
  fprintf(fp, "VARIABLES = \"Time\" \"Mean1\" \"Variance1\"  \"Mean2\" \"Variance2\" \"Mean3\" \"Variance3\"" );
  fprintf(fp,"\n");
  fprintf(fp,"ZONE I=%d, F=POINT\n", NumberToStore );
	
  double dt = 0.1;

  for ( int i = 0; i < NumberToStore ; i++){
	   double  time = i *dt;
       fprintf(fp, "%e\t ", time);
	   for ( int j = 0; j<DofPerNode ; j+=2)
	   fprintf(fp, "%e\t %e\t" ,  stat[i*DofPerNode+j],stat[i*DofPerNode+j+1]);
	   fprintf(fp, "\n");
	}
  fclose(fp);
  
}

