#include "SP4KO.h"
#include <time.h>
#include <mpi.h>

//-------------------------------------------------------------
// FORWARD DECLARATIONS
//-------------------------------------------------------------

int simulate();


int main(int argc,char **args)
{
	//Initialize MPI
	MPI_Init (&argc, &args);
	{
	// Simulator class
	 simulate();
	}

	MPI_Finalize (); //Finalize MPI environment.

	return 0;
}


int simulate()
{

	int dim = 1;
	int Lmax = 20;
	double epsilon = 1e-2;
	int type = 0;

	SP4KO sp(dim, Lmax, epsilon, type);
	
	int step = 3001;
	sp. SetTimeStep (step);
	sp.Solve();
		
	return 1;
}