#ifndef SP4KO_h_is_included
#define SP4KO_h_is_included


#include "SparseGrid.h"
#include "Direct.h"

class SP4KO: public AdaptiveSparseGrid
{

public:
   
	SP4KO(int dim ,int Lmax,double epsilon, int type);
	~SP4KO(){};

   int no_time_step;

   virtual void Solve(int print_ = 1, int restart_ = 0, char* filename = "surplus.plt");
   
   //Overloaded function from AdaptiveSparseGrid
   virtual void   EvaluateFunctionAtThisPoint( AdaptiveARRAY<double> *x);
   virtual void   SetTimeStep(int step);
   virtual int    IsRefine(double* value,AdaptiveARRAY<int> *ix,AdaptiveARRAY<int> *iy);

   Direct problem;

   virtual void Postprocess();
   virtual void StoreMeanAndVar(double* stat,char *filename);


};
#endif

 /*Class:SP4KO

NAME:  SP4KO - This is the class to solve the K-O problem.

DESCRIPTION:

  <b>This class solves the K-O problem.</b>

  For problem definition, please refer to the following paper:

  <b> Xiang Ma and N. Zabaras </b>
  An adaptive hierarchical sparse grid collocation algorithm for the solution
  of the stochastic differential equations, Journal of Computational Physics, Vol. 228, pp. 3084-3113, 2009.

CONSTRUCTORS AND INITIALIZATION:

   Use the same constructer as base class.

   You need to provide the tiem step in the function Solve().

MEMBER FUNCTIONS:


  Most member functions are self-explanatory.


COPYRIGHT:

        Professor Nicholas Zabaras
        Materials Process Design & Control Laboratory
        Sibley School of Mechanical and Aerospace Engineering
        101 Frank H. T. Rhodes Hall
        Cornell University
        Ithaca, NY 14853-3801

        Email: zabaras@cornell.edu
        Phone: 607 255 9104
        Fax:   607 255 1222


AUTHOR:

  Xiang Ma, xm25@cornell.edu

End:
*/
