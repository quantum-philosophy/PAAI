/*
  Filename : KO.h
  Prepared by : Xiang Ma and Nicholas Zabaras
  Version : March 14, 2008
*/

#ifndef KO_h_is_included
#define KO_h_is_included

#include "SparseGrid.h"

class KO
{

public:

	KO(){};
    ~KO(){};

   void init(int step, int dim_);

   virtual void Solve(double* x, double* surplus);

   int no_time_step;
   int dim;

  

};
#endif

