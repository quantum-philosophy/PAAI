#include "KO.h"




double f1(double y1, double y2)
{
   return y1*y2;
}

double f2(double y1, double y2)
{
   return -y1*y2;
}

double f3(double y1, double y2)
{
   return -pow(y1,2) + pow(y2,2);
} 

void KO::init(int step, int dim_)
{
   no_time_step = step;
   dim = dim_;
}

void KO::Solve( double* x, double* surplus)
{
	
	double y1,y2,y3;

	if(dim == 3)
	 {y1 = (-1+2* x[0]); y2= (-1+2*x[1]); y3= (-1+2*x[2]);}
    //2D
    if(dim == 2)
	{y1 = 1; y2= 0.1*(-1+2* x[0]); y3= (-1+2*x[1]);}
    //1D
    if(dim == 1)
	{y1 = 1; y2= 0.1*(-1+2* x[0]); y3= 0.0;}
	
	double dt = 0.01;

	int DofPerNode = 6;

    Array<double> k,L,M;

    k.redim(4); k.fill(0.0);
    L.redim(4); L.fill(0.0);
	M.redim(4); M.fill(0.0);

    int step = 1;
	int count = 0;

    while ( step < no_time_step )
    {

	  k(1) =  f1(y1,y3);
	  L(1) =  f2(y2,y3);
	  M(1) =  f3(y1,y2);

     
      k(2) =  f1(y1 + dt/2*k(1), y3+dt/2*M(1));
      L(2) =  f2(y2 + dt/2*L(1), y3+dt/2*M(1));
      M(2) =  f3(y1 + dt/2*k(1), y2+dt/2*L(1));

	  
      k(3) =  f1(y1 + dt/2*k(2), y3+dt/2*M(2));
      L(3) =  f2(y2 + dt/2*L(2), y3+dt/2*M(2));
      M(3) =  f3(y1 + dt/2*k(2), y2+dt/2*L(2));

	  
      k(4) =  f1(y1 + dt*k(3), y3+dt*M(3));
      L(4) =  f2(y2 + dt*L(3), y3+dt*M(3));
      M(4) =  f3(y1 + dt*k(3), y2+dt*L(3));

      if( step%10 == 1){

		    surplus[count*DofPerNode]     = y1;   surplus[count*DofPerNode + 1] = pow(y1,2); 
		   	surplus[count*DofPerNode + 2] = y2;   surplus[count*DofPerNode + 3] = pow(y2,2);
			surplus[count*DofPerNode + 4] = y3;   surplus[count*DofPerNode + 5] = pow(y3,2);
			count++;
		}

      y1 += dt/6*(k(1) + 2*k(2) + 2*k(3) + k(4));
      y2 += dt/6*(L(1) + 2*L(2) + 2*L(3) + L(4));
      y3 += dt/6*(M(1) + 2*M(2) + 2*M(3) + M(4));


      step += 1;

	}

	surplus[count*DofPerNode]     = y1;   surplus[count*DofPerNode + 1] = pow(y1,2); 
	surplus[count*DofPerNode + 2] = y2;   surplus[count*DofPerNode + 3] = pow(y2,2);
	surplus[count*DofPerNode + 4] = y3;   surplus[count*DofPerNode + 5] = pow(y3,2);
}

